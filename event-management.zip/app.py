from flask import Flask, render_template, request, redirect, url_for, g
import sqlite3
import os

BASE_DIR = os.path.dirname(os.path.abspath(__file__))
DB_PATH = os.path.join(BASE_DIR, "data", "events.db")

app = Flask(__name__)

def get_db():
    db = getattr(g, "_database", None)
    if db is None:
        db = g._database = sqlite3.connect(DB_PATH)
        db.row_factory = sqlite3.Row
    return db

@app.teardown_appcontext
def close_connection(exception):
    db = getattr(g, "_database", None)
    if db is not None:
        db.close()

@app.route("/")
def index():
    db = get_db()
    cur = db.execute("SELECT id, title, date, location FROM events ORDER BY date")
    events = cur.fetchall()
    return render_template("index.html", events=events)

@app.route("/event/new", methods=["GET", "POST"])
def new_event():
    if request.method == "POST":
        title = request.form.get("title")
        date = request.form.get("date")
        location = request.form.get("location")
        description = request.form.get("description")
        db = get_db()
        db.execute(
            "INSERT INTO events (title, date, location, description) VALUES (?, ?, ?, ?)",
            (title, date, location, description),
        )
        db.commit()
        return redirect(url_for("index"))
    return render_template("event_form.html")

@app.route("/event/<int:event_id>")
def view_event(event_id):
    db = get_db()
    cur = db.execute("SELECT * FROM events WHERE id = ?", (event_id,))
    event = cur.fetchone()
    if event is None:
        return "Event not found", 404
    return render_template("event_view.html", event=event)

if __name__ == "__main__":
    # ensure data folder exists
    os.makedirs(os.path.join(BASE_DIR, "data"), exist_ok=True)
    # if DB missing, instruct user to run setup or it will use included DB
    app.run(debug=True)
