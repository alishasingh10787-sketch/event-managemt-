# Event Management (Flask + SQLite)
Simple Event Management web app built with Flask and SQLite.

## Features
- Create / list / view events
- SQLite database included (`data/events.db`)
- Minimal HTML + CSS

## Run locally
1. Create a virtualenv: `python -m venv venv`
2. Activate it: `source venv/bin/activate` (mac/linux) or `venv\Scripts\activate` (Windows)
3. Install requirements: `pip install -r requirements.txt`
4. Run: `python app.py`
5. Open http://127.0.0.1:5000

## Project structure
- app.py           : Flask application
- templates/       : HTML templates
- static/          : CSS
- data/events.db   : SQLite DB (sample data)
- requirements.txt : Python deps
