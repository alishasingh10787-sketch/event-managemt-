
import java.sql.*;
import java.util.Scanner;

public class Booking {
    public static void bookTicket() {
        try (Connection con = Database.connect()) {
            Scanner sc = new Scanner(System.in);
            System.out.print("Enter Passenger Name: ");
            String name = sc.nextLine();

            System.out.print("Enter Train Name: ");
            String train = sc.nextLine();

            PreparedStatement ps = con.prepareStatement("INSERT INTO bookings (passenger, train) VALUES (?, ?)");
            ps.setString(1, name);
            ps.setString(2, train);
            ps.execute();

            System.out.println("✅ Ticket Booked Successfully!");
        } catch (Exception e) {
            System.out.println("Booking Failed");
        }
    }

    public static void viewBookings() {
        try (Connection con = Database.connect()) {
            Statement st = con.createStatement();
            ResultSet rs = st.executeQuery("SELECT * FROM bookings");

            System.out.println("\n---- Bookings ----");
            while (rs.next()) {
                System.out.println(rs.getInt(1) + " | " + rs.getString(2) + " | " + rs.getString(3));
            }
        } catch (Exception e) {
            System.out.println("Error loading bookings");
        }
    }
}
