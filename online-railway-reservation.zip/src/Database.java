
import java.sql.*;

public class Database {
    public static Connection connect() {
        try {
            return DriverManager.getConnection("jdbc:sqlite:data/railway.db");
        } catch (Exception e) {
            return null;
        }
    }

    public static void setup() {
        try (Connection con = connect()) {
            Statement st = con.createStatement();
            st.execute("CREATE TABLE IF NOT EXISTS trains (id INTEGER PRIMARY KEY, name TEXT, source TEXT, destination TEXT)");
            st.execute("CREATE TABLE IF NOT EXISTS bookings (id INTEGER PRIMARY KEY AUTOINCREMENT, passenger TEXT, train TEXT)");
        } catch (Exception e) {
            System.out.println("DB Error");
        }
    }
}
