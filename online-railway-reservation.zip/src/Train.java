
import java.sql.*;

public class Train {
    public static void viewTrains() {
        try (Connection con = Database.connect()) {
            Statement st = con.createStatement();
            ResultSet rs = st.executeQuery("SELECT * FROM trains");

            System.out.println("\nAvailable Trains:");
            while (rs.next()) {
                System.out.println(rs.getInt(1) + " | " + rs.getString(2) + " | " + rs.getString(3) + " ➝ " + rs.getString(4));
            }
        } catch (Exception e) {
            System.out.println("Error loading trains");
        }
    }
}
