
import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        Database.setup();

        while (true) {
            System.out.println("\n===== ONLINE RAILWAY RESERVATION SYSTEM =====");
            System.out.println("1. View Trains");
            System.out.println("2. Book Ticket");
            System.out.println("3. View Bookings");
            System.out.println("4. Exit");
            System.out.print("Enter choice: ");
            int ch = sc.nextInt();

            switch (ch) {
                case 1:
                    Train.viewTrains();
                    break;
                case 2:
                    Booking.bookTicket();
                    break;
                case 3:
                    Booking.viewBookings();
                    break;
                case 4:
                    System.out.println("Thank you!");
                    return;
                default:
                    System.out.println("Invalid choice!");
            }
        }
    }
}
