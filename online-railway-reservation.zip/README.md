
# Online Railway Reservation System (Java + SQLite)

## Features
- User Registration
- View Trains
- Book Ticket
- View Bookings
- SQLite Database Included

## How to Run
1. Install JDK 8+
2. Open terminal in project folder
3. Compile:
   javac -cp ".;lib/sqlite-jdbc.jar" src/*.java
4. Run:
   java -cp ".;lib/sqlite-jdbc.jar;src" Main

## Folder Structure
- src/  → Java source codes
- data/ → SQLite database
- lib/  → JDBC driver
